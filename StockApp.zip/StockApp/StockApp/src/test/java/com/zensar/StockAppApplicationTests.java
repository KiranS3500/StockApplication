package com.zensar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
